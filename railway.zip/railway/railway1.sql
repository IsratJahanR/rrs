-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 02, 2023 at 06:51 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railway`
--

-- --------------------------------------------------------

--
-- Table structure for table `active`
--

CREATE TABLE `active` (
  `phone` char(11) DEFAULT NULL,
  `logintime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `active`
--

INSERT INTO `active` (`phone`, `logintime`) VALUES
('01914622617', '2023-01-14 06:35:31'),
('01914622617', '2023-01-14 06:35:31'),
('01914622617', '2023-01-14 06:46:26'),
('01547123103', '2023-01-14 06:46:55'),
('01914622617', '2023-01-14 07:40:24'),
('01914622617', '2023-01-14 13:29:42'),
('0195642100', '2023-01-14 13:50:08');

-- --------------------------------------------------------

--
-- Table structure for table `ekota`
--

CREATE TABLE `ekota` (
  `serial_no` int(11) NOT NULL,
  `dest` varchar(50) DEFAULT NULL,
  `arrival` time DEFAULT NULL,
  `departure` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ekota`
--

INSERT INTO `ekota` (`serial_no`, `dest`, `arrival`, `departure`) VALUES
(1, 'khulna', '00:09:00', '00:09:00'),
(2, 'naopara', '00:09:31', '00:09:34'),
(3, 'jashore', '00:10:02', '00:10:06'),
(4, 'mubarakganj', '00:10:47', '00:10:47'),
(5, 'kotchadpur', '00:11:00', '00:11:02'),
(6, 'darshana_halt', '00:11:25', '00:11:28'),
(7, 'chuadanga', '00:11:46', '00:11:49'),
(8, 'alomdanga', '00:12:07', '00:12:09'),
(10, 'noakhali', '24:43:56', '00:43:34');

-- --------------------------------------------------------

--
-- Table structure for table `lalmoni`
--

CREATE TABLE `lalmoni` (
  `serial_no` int(11) NOT NULL,
  `dest` varchar(50) DEFAULT NULL,
  `arrival` time DEFAULT NULL,
  `departure` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lalmoni`
--

INSERT INTO `lalmoni` (`serial_no`, `dest`, `arrival`, `departure`) VALUES
(1, 'khulna', '00:09:00', '00:09:00'),
(2, 'naopara', '00:09:31', '00:09:34'),
(3, 'jashore', '00:10:02', '00:10:06'),
(4, 'mubarakganj', '00:10:47', '00:10:47'),
(5, 'kotchadpur', '00:11:00', '00:11:02'),
(6, 'darshana_halt', '00:11:25', '00:11:28'),
(7, 'chuadanga', '00:11:46', '00:11:49'),
(8, 'alomdanga', '00:12:07', '00:12:09'),
(10, 'noakhali', '24:43:56', '00:43:34');

-- --------------------------------------------------------

--
-- Table structure for table `rocket`
--

CREATE TABLE `rocket` (
  `serial_no` int(11) NOT NULL,
  `dest` varchar(50) DEFAULT NULL,
  `arrival` time DEFAULT NULL,
  `departure` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rocket`
--

INSERT INTO `rocket` (`serial_no`, `dest`, `arrival`, `departure`) VALUES
(1, 'khulna', '00:09:00', '00:09:00'),
(2, 'naopara', '00:09:31', '00:09:34'),
(3, 'jashore', '00:10:02', '00:10:06'),
(4, 'mubarakganj', '00:10:47', '00:10:47'),
(5, 'kotchadpur', '00:11:00', '00:11:02'),
(6, 'darshana_halt', '00:11:25', '00:11:28'),
(7, 'chuadanga', '00:11:46', '00:11:49'),
(8, 'alomdanga', '00:12:07', '00:12:09'),
(10, 'noakhali', '24:43:56', '00:43:34');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `tr_no` smallint(6) DEFAULT NULL,
  `src` varchar(50) DEFAULT NULL,
  `dest` varchar(50) DEFAULT NULL,
  `src_departure` time DEFAULT NULL,
  `dest_arrival` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`tr_no`, `src`, `dest`, `src_departure`, `dest_arrival`) VALUES
(701, 'khulna', 'dhaka', NULL, NULL),
(701, 'khulna', 'jashore', NULL, NULL),
(702, 'dhaka', 'khulna', NULL, NULL),
(702, 'dhaka', 'jashore', NULL, NULL),
(702, 'dhaka', 'kotchadpur', NULL, NULL),
(401, 'khulna', 'jashore', NULL, NULL),
(401, 'khulna', 'kotchadpur', NULL, NULL),
(701, 'khulna', 'naopara', '00:09:31', '00:09:34'),
(701, 'khulna', 'mubarakganj', '00:10:47', '00:10:47'),
(701, 'khulna', 'darshana_halt', '00:11:25', '00:11:28'),
(701, 'khulna', 'chuadanga', '00:11:26', '00:11:49'),
(701, 'khulna', 'alomdanga', '00:12:07', '00:12:09'),
(701, 'khulna', 'poradaha', '00:12:24', '00:12:27');

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `tr_no` smallint(6) NOT NULL,
  `tr_name` varchar(100) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `dest` varchar(50) DEFAULT NULL,
  `available_seat` smallint(6) DEFAULT NULL,
  `sat` tinyint(1) DEFAULT 1,
  `sun` tinyint(1) DEFAULT 1,
  `mon` tinyint(1) DEFAULT 1,
  `tue` tinyint(1) DEFAULT 1,
  `wed` tinyint(1) DEFAULT 1,
  `thu` tinyint(1) DEFAULT 1,
  `fri` tinyint(1) DEFAULT 1,
  `departure_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`tr_no`, `tr_name`, `source`, `dest`, `available_seat`, `sat`, `sun`, `mon`, `tue`, `wed`, `thu`, `fri`, `departure_time`, `arrival_time`) VALUES
(401, 'lalmoni express', 'khulna', 'dinajpur', 890, 1, 1, 1, 1, 1, 1, 1, NULL, NULL),
(402, 'lalmoni express', 'dinajpur', 'khulna', 900, 1, 1, 1, 1, 1, 1, 1, NULL, NULL),
(501, 'turna express', 'khulna', 'gopalganj', 800, 1, 1, 1, 1, 1, 1, 1, NULL, NULL),
(502, 'turna express', 'gopalganj', 'khulna', 800, 1, 1, 1, 1, 1, 1, 1, NULL, NULL),
(701, 'rocket', 'khulna', 'dhaka', 1000, 1, 0, 1, 1, 1, 1, 1, NULL, NULL),
(702, 'rocket', 'dhaka', 'khulna', 1000, 1, 0, 1, 1, 1, 1, 1, NULL, NULL),
(801, 'ekota express', 'dhaka', 'rajshahi', 500, 1, 1, 1, 1, 0, 1, 1, NULL, NULL),
(802, 'ekota express', 'rajshahi', 'dhaka', 500, 1, 1, 1, 1, 0, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(50) NOT NULL,
  `phone` char(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `nid` char(10) DEFAULT NULL,
  `password` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `phone`, `email`, `nid`, `password`) VALUES
('Muslim Uddin', '01547123100', 'muslim@gmail.com', '6013204472', '123456'),
('Nahidul Islam', '01547123103', 'nahidul@gmail.com', '6013204472', '123456'),
('Ashfak Shahrier', '01547123685', 'ashfak@gmail.com', '6013204472', '123456'),
('Abu Bokkor', '01547123686', 'bokkor@gmail.com', '6013204477', '123456'),
('Shahin Alom', '01547123810', 'shahin@gmail.com', '6013204480', '123456'),
('Arif Islam', '01547123811', 'arif@gmail.com', '6013204481', '123456'),
('Rakib Hossain', '01766753800', 'rakib@gmail.com', '6013204480', '123456'),
('Hamid', '01914622000', 'hamid@gmail.com', '6013204412', '$2y$10$noscv74KG.mV08UwNhs3/erxwmZucJl/sV.aUC8QAEAGWCD0At1p6'),
('Imran Mondal', '01914622101', 'imran@gmail.com', '6013204471', '123456'),
('Liton Khan', '01914622500', 'liton@gmail.com', '6013204472', '123456'),
('Shanto', '01914622600', 'shanto@gmail.com', '6013204475', '123456'),
('Rasel Hoque', '01914622615', 'rasel@gmail.com', '6013204474', '123456'),
('Rayhan Islam', '01914622616', 'rayhan@gmail.com', '6013204475', '123456'),
('Solaiman Hossain', '01914622617', 'slmnsnto@gmail.com', '6013204471', '123456'),
('Joydeb Gain', '01914622711', 'joydeb@gmail.com', '6013204472', '$2y$10$YLh.GRAaDfFUx6FfqPMtNezg.J2MPNuJfRT5bpDPtei/KsgshczKu'),
('Shimanto ', '0195642100', 'shimanto@gmail.com', '6013204371', '$2y$10$0G2gJfNT0pZukGRVARIb1enx23QE9/9U1lvacYeMYL581Z0TScP8S'),
('Nayon Kha', '0195642148', 'nayon@gmail.com', '1254789630', '$2y$10$e/k1YTrEqBbx4Aquh9i4f.SIpMSL3RHJ6xSUjVZRZzkVd67Kw8w/2'),
('Israt Jahan', '01958456217', 'israt@gmail.com', '6013204473', '123456'),
('Romizul Islam', '01958456219', 'romizul@gmail.com', '6013204499', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active`
--
ALTER TABLE `active`
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `ekota`
--
ALTER TABLE `ekota`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `lalmoni`
--
ALTER TABLE `lalmoni`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `rocket`
--
ALTER TABLE `rocket`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD KEY `tr_no` (`tr_no`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`tr_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ekota`
--
ALTER TABLE `ekota`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `lalmoni`
--
ALTER TABLE `lalmoni`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `rocket`
--
ALTER TABLE `rocket`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active`
--
ALTER TABLE `active`
  ADD CONSTRAINT `active_ibfk_1` FOREIGN KEY (`phone`) REFERENCES `users` (`phone`);

--
-- Constraints for table `route`
--
ALTER TABLE `route`
  ADD CONSTRAINT `route_ibfk_1` FOREIGN KEY (`tr_no`) REFERENCES `train` (`tr_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
