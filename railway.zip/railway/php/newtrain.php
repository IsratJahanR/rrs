
<?php

include("connection.php");
session_start();






?>



<!DOCTYPE html>
<html>
<head> 
        <title> Profile </title>
        <link rel="stylesheet" href="../css/style.css" >
		
    </head>
    <body class = "backimage">
	
	
 
		<nav class = "homeNav" > 
            <div class = "navDiv">
            <a class = "adminbutton" href="newtrain.php">Insert New Train</a>
            <a class = "adminbutton" href="updatetrain.php">Update Train info</a>
            </div>
        </nav>
		<br> <br> <br>
        <header>
            <h1>New Train insertion Here</h1>
        </header>
		<div class="newtrain">

        </div>
		
		

</body>
  
  
</html>